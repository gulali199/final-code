package com.smart.admin.sensors;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    Button logBtn;
    EditText loginId,pass;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        loginId=findViewById(R.id.loginId);
        pass=findViewById(R.id.password);
        logBtn=findViewById(R.id.logButton);

        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Please wait..");
        progressDialog.setCancelable(false);
        logBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show();
                if(getSharedPreferences("User",MODE_PRIVATE).getBoolean("loginStat",false)){
                    Toast.makeText(MainActivity.this, "Logged in already.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, Sensors.class));
                    finish();
                }else {
                    DatabaseReference reff = FirebaseDatabase.getInstance().getReference("Users").child("xyz");
                    reff.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                progressDialog.dismiss();
                                if (dataSnapshot.child("logPass").getValue().toString().equals(pass.getText().toString()) &&
                                        dataSnapshot.child("logId").getValue().toString().equals(loginId.getText().toString())) {
                                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                    SharedPreferences.Editor preff = getSharedPreferences("User", MODE_PRIVATE).edit();
                                    preff.putBoolean("loginStat", true);
                                    preff.commit();
                                    startActivity(new Intent(MainActivity.this, Sensors.class));
                                    finish();
                                } else {
                                    progressDialog.dismiss();
                                    Toast.makeText(MainActivity.this, "Password is wrong for this login ID", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                progressDialog.dismiss();
                                Toast.makeText(MainActivity.this, "No ID exists for this login ID", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Database Error!\n" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

}
