package com.smart.admin.sensors;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentActivity;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Sensors extends FragmentActivity implements OnMapReadyCallback {
    TextView status;
    private GoogleMap mMap;
    ImageButton logout;


    ValueEventListener listener;
    DatabaseReference reff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors);

        status = findViewById(R.id.status);
        logout=findViewById(R.id.btnLogout);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Sensors.this);
                builder.setTitle("Message").setMessage("Are you sure to logout?").
                        setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                getSharedPreferences("User", MODE_PRIVATE).edit().putBoolean("loginStat", false).apply();
                                startActivity(new Intent(Sensors.this, MainActivity.class));
                                finish();
                            }
                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {
        reff = FirebaseDatabase.getInstance().getReference();
        listener = reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("Alert").getValue().toString().equals("1")) {
                    raiseNotification();
                    status.setText("ON");
                    double lat = Double.parseDouble(dataSnapshot.child("Lat").getValue().toString());
                    double lon = Double.parseDouble(dataSnapshot.child("lon").getValue().toString());
                    mMap = googleMap;
                    LatLng sydney = new LatLng(lat, lon);
                    mMap.addMarker(new MarkerOptions().position(sydney).title("Sensor"));
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                } else {
                    status.setText("OFF");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private static final String CHANNEL_WHATEVER = "123";
    private static int NOTIFY_ID = 1337;
    private void raiseNotification() {
        NotificationManager mgr =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                mgr.getNotificationChannel(CHANNEL_WHATEVER) == null) {
            mgr.createNotificationChannel(new NotificationChannel(CHANNEL_WHATEVER,
                    "abc", NotificationManager.IMPORTANCE_DEFAULT));
        }

        NotificationCompat.Builder b =
                new NotificationCompat.Builder(this, CHANNEL_WHATEVER);

        b.setAutoCancel(true);
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        b.setContentTitle("Sensor Alert")
                .setContentText("Sensor has been avtivated")
                .setSmallIcon(android.R.drawable.alert_light_frame)
                .setAutoCancel(true)
                .setSound(alarmSound)
                .setOnlyAlertOnce(true);

        Intent intent = new Intent(this, Sensors.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);

        b.setContentIntent(pi);

        mgr.notify(NOTIFY_ID, b.build());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (listener != null) {
            reff.removeEventListener(listener);
        }
    }
}
